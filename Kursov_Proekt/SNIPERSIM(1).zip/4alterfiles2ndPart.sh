#step 7
cd ~/sniperSim/sniper-7.4/benchmarks/parsec/parsec-2.1/pkgs/libs/ssl/src
sed -i 's/install: all install_docs install_sw/install: all install_sw/g' Makefile.org

#step 9
#sed -i '140s/*/BBB/' file_name

cd ~/sniperSim/sniper-7.4/benchmarks/

sed -i '154,156{s/^/#/}' run-sniper
sed -i '138,140{s/^/#/}' run-sniper

#138-140

#step 8
make
