#get and unzip
cd ~/sniperSim/sniper-7.4
wget http://snipersim.org/packages/sniper-benchmarks.tbz
tar xjf sniper-benchmarks.tbz
rm sniper-benchmarks.tbz
cd benchmarks

#export
export GRAPHITE_ROOT=~/sniperSim/sniper-7.4
export BENCHMARKS_ROOT=~/sniperSim/sniper-7.4/benchmarks

# inital make to create the files for the next step
cd ~/sniperSim/sniper-7.4/benchmarks
make

