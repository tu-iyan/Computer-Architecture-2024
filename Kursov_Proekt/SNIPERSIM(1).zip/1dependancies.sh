#python env
sudo ln -s /usr/bin/python2 /usr/bin/python

#download and unzip sniper @ home directory
wget http://snipersim.org/download/e0442d64144b391e/packages/sniper-latest.tgz -O sniper-latest.tgz
mkdir ~/sniperSim
mv sniper-latest.tgz ~/sniperSim
tar -xvf ~/sniperSim/sniper-latest.tgz --directory ~/sniperSim


#install dependancies
yes | sudo apt update
yes | sudo apt --fix-broken install
yes | sudo apt install thunderbird
yes | sudo apt upgrade
yes | sudo apt install zlib1g-dev
yes | sudo apt install libbz2-dev
yes | sudo apt install g++
yes | sudo apt install libsqlite3-dev
yes | sudo apt install libboost-dev 
yes | sudo apt install m4
yes | sudo apt install xsltproc
yes | sudo apt install libx11-dev
yes | sudo apt install libxext-dev
yes | sudo apt install libxt-dev
yes | sudo apt install libxmu-dev
yes | sudo apt install libxi-dev
yes | sudo apt install python
yes | sudo apt install git
yes | sudo apt install gfortran
yes | sudo apt install pkg-config

#Download and unzip pin @ sniper dir
wget https://software.intel.com/sites/landingpage/pintool/downloads/pin-3.26-98690-g1fc9d60e6-gcc-linux.tar.gz -O pin_kit.tar.gz
mv pin_kit.tar.gz ~/sniperSim/sniper-7.4/pin_kit.tar.gz
tar -xvf ~/sniperSim/sniper-7.4/pin_kit.tar.gz --directory ~/sniperSim/sniper-7.4/
cd ~/sniperSim/sniper-7.4
mv pin-3.26-98690-g1fc9d60e6-gcc-linux pin_kit
rm pin_kit.tar.gz

#build sniper 
make -j 4

#test installation
cd test/fft; make run; cd ~/Desktop
