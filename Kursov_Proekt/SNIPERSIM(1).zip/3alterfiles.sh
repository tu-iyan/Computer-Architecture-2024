#do initial
export SNIPER_ROOT=~/sniperSim/sniper-7.4
export BENCHMARKS_ROOT=~/sniperSim/sniper-7.4/benchmarks

#do step 1
cd ~/sniperSim/sniper-7.4/benchmarks
sed -i 's/\tmake -C parsec/\t#make -C local/g' Makefile
sed -i 's/\tmake -C cpu2006/\t#make -C cpu2006/g' Makefile
sed -i 's/\tmake -C npb/\t#make -C npb/g' Makefile
sed -i 's/\tmake -C local/\t#make -C local/g' Makefile

sed -i 's/\tmake -C parsec clean/\t#make -C local clean/g' Makefile
sed -i 's/\tmake -C cpu2006 clean/\t#make -C cpu2006 clean/g' Makefile
sed -i 's/\tmake -C npb clean/\t#make -C npb clean/g' Makefile
sed -i 's/\tmake -C local clean/\t#make -C local clean/g' Makefile

#do step 2
cd ~/sniperSim/sniper-7.4/benchmarks/parsec/parsec-2.1/pkgs/apps/bodytrack/parsec
echo CXXFLAGS=\"-std=gnu++98 \${CXXFLAGS} \${HOOKS_CXXFLAGS}\" >> gcc-sniper.bldconf

#do step 3
cd ~/sniperSim/sniper-7.4/benchmarks/parsec/parsec-2.1/pkgs/apps/ferret/src/src/lsh
sed -i 's/ HUGE)/ HUGE_VAL)/g' LSH_query.c
sed -i 's/ HUGE)/ HUGE_VAL)/g' LSH_query_batch.c
cd ~/sniperSim/sniper-7.4/benchmarks/parsec/parsec-2.1/pkgs/apps/ferret/src/benchmark
sed -i 's/ HUGE)/ HUGE_VAL)/g' ferret-parallel.c
sed -i 's/ HUGE)/ HUGE_VAL)/g' ferret-serial.c

#do step 4
cd ~/sniperSim/sniper-7.4/benchmarks/parsec/parsec-2.1/pkgs/tools/cmake/parsec
sed -i '8 i build_env="CC=\"${CC}\" CXXFLAGS=\"-std=gnu++98 ${CXXFLAGS} -fexceptions\" LDFLAGS=\"-L${CC_HOME}/lib64 -L${CC_HOME}/lib -L${PARSECDIR}/pkgs/libs/hooks/inst/${PARSECPLAT}/lib\"")' gcc-sniper.bldconf
sed -i '9d' gcc-sniper.bldconf #deletes the old line

#do step 5
cd ~/sniperSim/sniper-7.4/benchmarks/parsec/parsec-2.1/pkgs/apps/x264/parsec
echo CC=\"\${HOOKS_CC} -no-pie\" >> gcc-sniper.bldconf

#do step 6 {it should give these errors:}
#smime.pod around line 272: Expected text after =item, not a number
#smime.pod around line 276: Expected text after =item, not a number
#smime.pod around line 280: Expected text after =item, not a number
#smime.pod around line 285: Expected text after =item, not a number
#smime.pod around line 289: Expected text after =item, not a number
cd ~/sniperSim/sniper-7.4/benchmarks/
make



